import { useEffect, useState } from "react";
import {
  DndContext, DragEndEvent, DragOverlay, closestCorners, PointerSensor, useSensor, useSensors
} from "@dnd-kit/core";
import {
  SortableContext, arrayMove, rectSortingStrategy, useSortable
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { DayBlock, WeekPlan } from "../types";
import BeltBadge from "../components/BeltBadge";
import BlockComposer from "../components/BlockComposer";

function BlockCard({block}:{block:DayBlock}) {
  const {attributes, listeners, setNodeRef, transform, transition} = useSortable({id: block.id});
  const style = { transform: CSS.Transform.toString(transform), transition };
  return (
    <div ref={setNodeRef} style={style}
      className="rounded-lg" >
      <div style={{display:'flex', alignItems:'center', gap:8, border:'1px solid var(--line)', background:'var(--panel)', borderRadius:12, padding:12}}>
        <button {...attributes} {...listeners} className="text-subtle" title="Drag">⋮⋮</button>
        <div style={{fontWeight:600}}>{block.title}</div>
        <div style={{marginLeft:'auto', display:'flex', alignItems:'center', gap:8}}>
          <BeltBadge belt={block.belt}/>
          <div className="text-subtle" style={{fontSize:10, textTransform:'uppercase'}}>{block.focus.join(" • ")}</div>
        </div>
      </div>
      {!!block.exercises.length && (
        <div className="text-subtle" style={{fontSize:12, marginTop:4}}>
          {block.exercises.slice(0,3).map(e=>e.name).join(", ")}{block.exercises.length>3 ? "…" : ""}
        </div>
      )}
      {block.notes && <div style={{fontSize:12, marginTop:4}}>{block.notes}</div>}
    </div>
  );
}

export default function PlannerPage(){
  const [week,setWeek] = useState<WeekPlan>({0:[],1:[],2:[],3:[],4:[],5:[],6:[]});
  const [composerOpen,setComposerOpen] = useState(false);
  const [composerDay,setComposerDay] = useState<number>(0);
  const [activeId,setActiveId] = useState<string|undefined>();

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 3 }}));

  useEffect(()=>{ (async()=>{
    try{
      const r = await fetch("/program/weekly?a=a1").then(r=>r.ok?r.json():null);
      if (r?.week) setWeek(r.week);
    } catch {}
  })(); },[]);

  const addBlock = (d:number, b:DayBlock) => {
    setWeek(prev => ({...prev, [d]: [...prev[d], b]}));
    fetch("/program/block/add", { method:"POST", headers:{ "content-type":"application/json" },
      body: JSON.stringify({ athlete_id:"a1", day_index:d, block:b })
    }).catch(()=>{});
  };

  const onDragEnd = (e:DragEndEvent)=>{
    const {active, over} = e;
    setActiveId(undefined);
    if (!over) return;

    let fromDay=-1, toDay=-1, fromIdx=-1, toIdx=-1, moving: DayBlock|undefined;
    for (let d=0; d<7; d++){
      const idx = week[d].findIndex(b=>b.id===active.id);
      if (idx>-1){ fromDay=d; fromIdx=idx; moving=week[d][idx]; break; }
    }
    if (!moving) return;

    const overIsDay = (typeof over.id==="string" && (over.id as string).startsWith("day:"));
    if (overIsDay){
      toDay = parseInt((over.id as string).split(":")[1],10);
      toIdx = week[toDay].length;
      setWeek(w=>{
        const removed = [...w[fromDay]]; removed.splice(fromIdx,1);
        const target = [...w[toDay]]; target.splice(toIdx,0,moving!);
        return {...w, [fromDay]:removed, [toDay]:target};
      });
    } else {
      for (let d=0; d<7; d++){
        const idx = week[d].findIndex(b=>b.id===over.id);
        if (idx>-1){ toDay=d; toIdx=idx; break; }
      }
      if (toDay===-1) return;
      if (fromDay===toDay){
        setWeek(w=>{
          const arr=[...w[fromDay]];
          // @ts-ignore
          const newArr=arrayMove(arr, fromIdx, toIdx);
          return {...w,[fromDay]:newArr};
        });
      } else {
        setWeek(w=>{
          const src=[...w[fromDay]]; src.splice(fromIdx,1);
          const dst=[...w[toDay]];   dst.splice(toIdx,0,moving!);
          return {...w, [fromDay]:src, [toDay]:dst};
        });
      }
    }

    fetch("/program/block/move",{
      method:"POST", headers:{ "content-type":"application/json"},
      body: JSON.stringify({
        athlete_id:"a1",
        block_id: active.id,
        to_day: (over.id as string).startsWith("day:") ? parseInt((over.id as string).split(":")[1],10) : toDay,
        to_index: toIdx
      })
    }).catch(()=>{});
  };

  const days = Array.from({length:7}, (_,d)=>d);

  return (
    <div style={{display:'flex', flexDirection:'column', gap:24, padding:24}}>
      <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
        <h1 style={{fontSize:24, fontWeight:600}}>Planner</h1>
        <div className="text-subtle">Drag blocks across days to reorder. Use “+” to compose new blocks.</div>
      </div>

      <DndContext sensors={sensors} collisionDetection={closestCorners}
        onDragStart={({active})=>setActiveId(String(active.id))}
        onDragEnd={onDragEnd}>
        <div style={{display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:12}}>
          {days.map(d=>(
            <div key={d} id={`day:${d}`} style={{border:'1px solid var(--line)', background:'rgba(255,255,255,0.03)', borderRadius:16, padding:12, minHeight:480}}>
              <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8}}>
                <div style={{fontWeight:600}}>Day {d+1}</div>
                <button onClick={()=>{ setComposerDay(d); setComposerOpen(true); }}
                        style={{fontSize:12, padding:'4px 8px', borderRadius:8, background:'rgba(255,255,255,0.08)', border:'1px solid var(--line)'}}>
                  + New
                </button>
              </div>
              <SortableContext items={(week[d]||[]).map(b=>b.id)} strategy={rectSortingStrategy}>
                <div style={{display:'flex', flexDirection:'column', gap:8, minHeight:40}}>
                  {(week[d]||[]).map(b=> <BlockCard key={b.id} block={b}/>)}
                </div>
              </SortableContext>
            </div>
          ))}
        </div>
        <DragOverlay>
          {activeId && (()=> {
            const b = Object.values(week).flat().find((x:any)=>x.id===activeId);
            return b ? <div style={{opacity:0.85}}><BlockCard block={b}/></div> : null;
          })()}
        </DragOverlay>
      </DndContext>

      <BlockComposer
        open={composerOpen}
        onClose={()=>setComposerOpen(false)}
        onCreate={(block)=> addBlock(composerDay, block)}
      />
    </div>
  );
}
