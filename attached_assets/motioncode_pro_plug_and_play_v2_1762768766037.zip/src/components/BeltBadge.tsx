import { Belt } from "../types";

const COLORS: Record<Belt,string> = {
  white: "background:white; color:#0b0b0c;",
  blue: "background:#3b82f6; color:white;",
  black: "background:#000; color:white; border:1px solid rgba(255,255,255,0.18)"
};

export default function BeltBadge({belt}:{belt:Belt}) {
  return <span style={{padding:'2px 8px', borderRadius:8, fontSize:10, ...(Object.fromEntries(COLORS[belt].split(';').filter(Boolean).map(s=>s.split(':')) as any)) as any}}>{belt.toUpperCase()}</span>;
}
