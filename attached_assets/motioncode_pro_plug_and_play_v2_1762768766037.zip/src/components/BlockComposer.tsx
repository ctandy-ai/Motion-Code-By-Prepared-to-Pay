import { useEffect, useMemo, useState } from "react";
import useSWR from "swr";
import { Belt, DayBlock, ExerciseRef, Focus } from "../types";
import { id } from "../util/id";
import BeltBadge from "./BeltBadge";

const fetcher = (u:string)=>fetch(u).then(r=>r.json());

const FOCI: Focus[] = ["accel","decel","cod","sprint","strength","power","capacity"];
const BELTS: Belt[] = ["white","blue","black"];

export default function BlockComposer({
  open, onClose, onCreate
}:{
  open: boolean;
  onClose: ()=>void;
  onCreate: (b: DayBlock)=>void;
}) {
  const { data } = useSWR(open ? "/master_exercises" : null, fetcher);
  const [belt,setBelt] = useState<Belt>("white");
  const [title,setTitle] = useState("S&C + Field");
  const [focus,setFocus] = useState<Focus[]>(["strength"]);
  const [q,setQ] = useState("");
  const [notes,setNotes] = useState("");
  const [picked,setPicked] = useState<ExerciseRef[]>([]);

  useEffect(()=>{ if (!open){ setPicked([]); setTitle("S&C + Field"); setNotes(""); setBelt("white"); setFocus(["strength"]); setQ(""); }},[open]);

  const list = useMemo(()=>{
    let items = (data?.items||[]) as any[];
    if (q) items = items.filter(x=>x.name.toLowerCase().includes(q.toLowerCase()));
    return items.slice(0,300);
  },[data,q]);

  const toggleFocus = (f:Focus)=> setFocus(s => s.includes(f) ? s.filter(x=>x!==f) : [...s,f]);

  const add = (ex:any)=>{
    if (picked.some(p=>p.id===ex.id)) return;
    setPicked(p=>[...p, { id: ex.id, name: ex.name, scheme: ex.defaults?.scheme || "" }]);
  };
  const updateScheme = (i:number, scheme:string)=>{
    setPicked(p=>p.map((x,ix)=> ix===i ? {...x, scheme} : x));
  };

  const create = ()=>{
    const block: DayBlock = {
      id: id(),
      belt, title, focus, notes,
      exercises: picked
    };
    onCreate(block);
    onClose();
  };

  if (!open) return null;

  return (
    <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,0.6)', zIndex:50, display:'flex', alignItems:'flex-start', justifyContent:'center', padding:24}}>
      <div style={{width:980, maxHeight:'90vh', overflow:'auto', background:'var(--panel)', border:'1px solid var(--line)', borderRadius:16, padding:20}}>
        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
          <div style={{fontSize:18, fontWeight:600}}>New Block</div>
          <button onClick={onClose} className="text-subtle">Close</button>
        </div>

        <div style={{display:'grid', gridTemplateColumns:'2fr 1fr', gap:16, marginTop:16}}>
          <div>
            <input style={{width:'100%', background:'var(--ink)', border:'1px solid var(--line)', borderRadius:8, padding:8}} value={title} onChange={e=>setTitle(e.target.value)} placeholder="Block title"/>
            <div style={{height:8}}/>
            <div style={{display:'flex', gap:8}}>
              {BELTS.map(b=>
                <button key={b} onClick={()=>setBelt(b)} style={{border:'1px solid var(--line)', background:'var(--ink)', borderRadius:8, padding:'6px 10px'}}>
                  <BeltBadge belt={b}/>
                </button>
              )}
            </div>
            <div style={{height:8}}/>
            <div style={{display:'flex', gap:8, flexWrap:'wrap'}}>
              {FOCI.map(f=>
                <button key={f} onClick={()=>toggleFocus(f)}
                  style={{padding:'6px 10px', borderRadius:999, border:'1px solid var(--line)', background: focus.includes(f)?'rgba(0,224,164,0.15)':'var(--ink)'}}>
                  {f}
                </button>
              )}
            </div>
            <div style={{height:8}}/>
            <textarea style={{width:'100%', height:120, background:'var(--ink)', border:'1px solid var(--line)', borderRadius:8, padding:8}}
                      placeholder="Coach notes (intent, constraints, exposure caps)…"
                      value={notes} onChange={e=>setNotes(e.target.value)} />
            <div style={{height:8}}/>
            <div>
              <div className="text-subtle" style={{fontSize:12, marginBottom:4}}>Selected exercises</div>
              <div style={{display:'flex', flexDirection:'column', gap:8}}>
                {picked.map((p,i)=>(
                  <div key={p.id} style={{display:'flex', alignItems:'center', gap:8, background:'rgba(255,255,255,0.02)', border:'1px solid var(--line)', borderRadius:8, padding:8}}>
                    <div style={{fontWeight:500}}>{p.name}</div>
                    <input style={{marginLeft:'auto', background:'var(--ink)', border:'1px solid var(--line)', borderRadius:6, padding:6, fontSize:12, width:220}}
                           placeholder="e.g., 4x6 @ RPE7"
                           value={p.scheme||""}
                           onChange={e=>updateScheme(i, e.target.value)} />
                    <button className="text-subtle" onClick={()=>setPicked(ps=>ps.filter((_,ix)=>ix!==i))}>Remove</button>
                  </div>
                ))}
                {!picked.length && <div className="text-subtle" style={{fontSize:12}}>No exercises yet.</div>}
              </div>
            </div>
          </div>

          <div>
            <div className="text-subtle" style={{fontSize:12, marginBottom:4}}>Library</div>
            <input style={{width:'100%', background:'var(--ink)', border:'1px solid var(--line)', borderRadius:8, padding:8, marginBottom:8}} placeholder="Search…" value={q} onChange={e=>setQ(e.target.value)} />
            <div style={{maxHeight:'55vh', overflow:'auto', display:'flex', flexDirection:'column', gap:8, paddingRight:4}}>
              {(list||[]).map((x:any)=>(
                <div key={x.id} style={{border:'1px solid var(--line)', borderRadius:8, padding:8}}>
                  <div style={{fontWeight:500, fontSize:13}}>{x.name}</div>
                  <div className="text-subtle" style={{fontSize:11}}>{(x.tags||[]).slice(0,3).join(", ")}</div>
                  <div className="text-subtle" style={{fontSize:11}}>{x.defaults?.scheme || "—"}</div>
                  <button style={{marginTop:4}} className="text-accent" onClick={()=>add(x)}>Add</button>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div style={{marginTop:16, display:'flex', justifyContent:'flex-end', gap:8}}>
          <button onClick={onClose} style={{padding:'8px 14px', borderRadius:8, border:'1px solid var(--line)'}}>Cancel</button>
          <button onClick={create} style={{padding:'8px 14px', borderRadius:8, background:'var(--accent)', color:'#0b0b0c', fontWeight:700}}>Create Block</button>
        </div>
      </div>
    </div>
  );
}
