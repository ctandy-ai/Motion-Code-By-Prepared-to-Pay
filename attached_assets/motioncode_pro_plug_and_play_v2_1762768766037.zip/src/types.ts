export type Belt = "white" | "blue" | "black";
export type Focus = "accel" | "decel" | "cod" | "sprint" | "strength" | "power" | "capacity";

export type ExerciseRef = {
  id: string;
  name: string;
  scheme?: string;    // e.g., "4x6 @ RPE7"
};

export type DayBlock = {
  id: string;
  belt: Belt;
  title: string;
  focus: Focus[];
  notes?: string;
  exercises: ExerciseRef[];
};

export type WeekPlan = Record<number, DayBlock[]>; // 0..6
