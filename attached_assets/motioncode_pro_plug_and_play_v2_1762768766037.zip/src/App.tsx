export default function App(){
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold">MotionCode Pro</h1>
      <p className="text-subtle mt-2">Go to the <a href="/planner">Planner</a>.</p>
    </div>
  );
}
