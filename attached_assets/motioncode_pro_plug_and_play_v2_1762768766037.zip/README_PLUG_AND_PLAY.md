# MotionCode Pro — Plug & Play (Planner + Composer + Minimal Server)

## Quick start
1) Upload all files into your Replit project root.
2) In the Replit shell run:
   ```bash
   npm i
   npm run dev
   ```
3) Open the web preview → `/planner`

You can compose blocks from the Master Exercise DB (seeded with demo items).  
Use these endpoints:
- `GET /master_exercises?q=rdl&limit=500`
- `POST /admin/seed_exercises` with body:
  ```json
  { "items": [ { "id":"ex_id", "name":"Name", "tags":["lower"], "defaults":{"scheme":"4x6 @ RPE7"} } ] }
  ```
- `GET /program/weekly?a=a1`
- `POST /program/block/add`
- `POST /program/block/move`

## Import your full master list
- Convert your exercise list to JSON array with fields: `id`, `name`, `tags[]`, `defaults.scheme`.
- POST to `/admin/seed_exercises` (this replaces existing items).

## Build for production
```bash
npm run build
node server/index.js  # serves dist/ and API on :3000
```

## Notes
- Styling uses simple CSS variables in `index.html`. Swap to Tailwind later if you prefer.
- DB: SQLite (`motioncode.db`) created in project root.
