import fs from "fs";
import Database from "better-sqlite3";

const db = new Database("motioncode.db");
db.exec(`CREATE TABLE IF NOT EXISTS exercises(
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  tags TEXT,
  defaults TEXT
);`);

const demo = JSON.parse(fs.readFileSync("data/demo_exercises.json","utf8"));
const ins = db.prepare("INSERT INTO exercises(id,name,tags,defaults) VALUES(?,?,?,?)");
const trx = db.transaction(()=>{
  db.exec("DELETE FROM exercises;");
  for (const x of demo){
    ins.run(x.id, x.name, JSON.stringify(x.tags||[]), JSON.stringify(x.defaults||{}));
  }
});
trx();
console.log("Seeded demo exercises:", demo.length);
