import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/master_exercises': 'http://localhost:3000',
      '/program': 'http://localhost:3000',
      '/admin': 'http://localhost:3000'
    }
  },
  build: {
    outDir: 'dist'
  }
})
