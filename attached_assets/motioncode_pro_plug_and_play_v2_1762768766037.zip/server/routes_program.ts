import type { Express } from "express";
import Database from "better-sqlite3";

export function mountProgramRoutes(app: Express, db: Database){
  app.get("/program/weekly", (req, res)=>{
    const athlete_id = String(req.query.a||"a1");
    const row = db.prepare(`SELECT json FROM weekly_plans WHERE athlete_id=?`).get(athlete_id);
    if (!row) return res.json({ week: {0:[],1:[],2:[],3:[],4:[],5:[],6:[]} });
    res.json({ week: JSON.parse(row.json) });
  });

  app.post("/program/block/add", (req,res)=>{
    const { athlete_id, day_index, block } = req.body;
    const r = db.prepare(`SELECT json FROM weekly_plans WHERE athlete_id=?`).get(athlete_id);
    let week = r ? JSON.parse(r.json) : {0:[],1:[],2:[],3:[],4:[],5:[],6:[]};
    week[day_index].push(block);
    db.prepare(`INSERT INTO weekly_plans(athlete_id,json) VALUES(?,?)
                ON CONFLICT(athlete_id) DO UPDATE SET json=excluded.json`)
      .run(athlete_id, JSON.stringify(week));
    res.json({ ok:true });
  });

  app.post("/program/block/move", (req,res)=>{
    const { athlete_id, block_id, to_day, to_index } = req.body;
    const r = db.prepare(`SELECT json FROM weekly_plans WHERE athlete_id=?`).get(athlete_id);
    if (!r) return res.status(404).json({error:"no plan"});
    const week = JSON.parse(r.json);
    let found;
    for (let d=0; d<7; d++){
      const i = week[d].findIndex((b:any)=>b.id===block_id);
      if (i>-1){ found = week[d].splice(i,1)[0]; break; }
    }
    if (!found) return res.status(404).json({error:"not found"});
    week[to_day].splice(to_index,0,found);
    db.prepare(`UPDATE weekly_plans SET json=? WHERE athlete_id=?`).run(JSON.stringify(week), athlete_id);
    res.json({ ok:true });
  });
}
