import type { Express } from "express";
import Database from "better-sqlite3";

type Exercise = { id:string; name:string; tags?:string[]; defaults?:{scheme?:string} };

export function mountExerciseRoutes(app: Express, db: Database){
  db.exec(`CREATE TABLE IF NOT EXISTS exercises(
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    tags TEXT,
    defaults TEXT
  );`);

  app.get("/master_exercises", (req,res)=>{
    const q = String(req.query.q||"").toLowerCase();
    const limit = Math.min(Number(req.query.limit||500), 1000);
    let rows = db.prepare(`SELECT id,name,tags,defaults FROM exercises`).all();
    if (q) rows = rows.filter(r => r.name.toLowerCase().includes(q) || (JSON.parse(r.tags||"[]") as string[]).some(t=>t.toLowerCase().includes(q)));
    const items = rows.slice(0,limit).map(r => ({
      id:r.id, name:r.name,
      tags: JSON.parse(r.tags||"[]"),
      defaults: JSON.parse(r.defaults||"{}")
    }));
    res.json({ items });
  });

  // Bulk seed/replace all (admin)
  app.post("/admin/seed_exercises", (req,res)=>{
    const items = (req.body?.items||[]) as Exercise[];
    const trx = db.transaction(()=>{
      db.exec("DELETE FROM exercises;");
      const ins = db.prepare(`INSERT INTO exercises(id,name,tags,defaults) VALUES(?,?,?,?)`);
      for (const x of items){
        ins.run(x.id, x.name, JSON.stringify(x.tags||[]), JSON.stringify(x.defaults||{}));
      }
    });
    try { trx(); } catch(e:any){ return res.status(400).json({error:String(e)}); }
    res.json({ ok:true, count: items.length });
  });
}
