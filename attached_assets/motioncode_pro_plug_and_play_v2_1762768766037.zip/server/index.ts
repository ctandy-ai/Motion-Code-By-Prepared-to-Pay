import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import Database from "better-sqlite3";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { mountProgramRoutes } from "./routes_program.js";
import { mountExerciseRoutes } from "./routes_exercises.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
app.use(cors());
app.use(bodyParser.json({limit:"10mb"}));

// SQLite
const db = new Database("motioncode.db");
db.exec(fs.readFileSync(path.join(__dirname,"schema.sql"),"utf8"));
mountProgramRoutes(app, db);
mountExerciseRoutes(app, db);

// Seed demo if exercises empty
const count = db.prepare("SELECT COUNT(*) as n FROM exercises").get().n;
if (!count){
  const demo = JSON.parse(fs.readFileSync(path.join(__dirname,"../data/demo_exercises.json"),"utf8"));
  const ins = db.prepare("INSERT INTO exercises(id,name,tags,defaults) VALUES(?,?,?,?)");
  const trx = db.transaction(()=>{
    for (const x of demo){
      ins.run(x.id, x.name, JSON.stringify(x.tags||[]), JSON.stringify(x.defaults||{}));
    }
  });
  trx();
  console.log(`Seeded demo exercises: ${demo.length}`);
}

// Static: serve built client if exists
const dist = path.join(__dirname, "..", "dist");
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get("*", (_req,res)=> res.sendFile(path.join(dist,"index.html")));
}

const PORT = Number(process.env.PORT || 3000);
app.listen(PORT, ()=> console.log(`API on :${PORT}`));
