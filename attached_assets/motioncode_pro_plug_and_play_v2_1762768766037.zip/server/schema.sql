CREATE TABLE IF NOT EXISTS weekly_plans(
  athlete_id TEXT PRIMARY KEY,
  json TEXT NOT NULL
);
